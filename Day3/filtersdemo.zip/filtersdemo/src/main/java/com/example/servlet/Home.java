package com.example.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


//@WebServlet("/home")
public class Home extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Home() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("<head><title>Home Page</title></head>");
		out.println("<body>");
		out.println("<h1>Welcome to the Home Page</h1>");
		out.println("<p>This page is protected by a filter.</p>");
		out.println("<p>Current Time: " + new java.util.Date() + "</p>");
		out.println("</body>");
		out.println("</html>");
		out.close();
		
		System.out.println("HomeServlet is processing the GET request.");
		response.getWriter().println("<h2>Welcome to the Home Page!</h2>");
		
	}

	

}
