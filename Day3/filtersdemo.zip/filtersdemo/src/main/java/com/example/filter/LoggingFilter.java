package com.example.filter;

import java.io.IOException;
import java.util.Date;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;

@WebFilter("/*")
public class LoggingFilter implements Filter {
	
	

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		
		HttpServletRequest httpRequest = (HttpServletRequest) request;
		
		String clientIP = request.getRemoteAddr();
		String requestURL = httpRequest.getRequestURL().toString();
		String requestMethod = httpRequest.getMethod();
		Date requestTime = new java.util.Date();
		
		System.out.println("Client IP: " + clientIP);	
		System.out.println("Request URL: " + requestURL);
		System.out.println("Request Method: " + requestMethod);
		System.out.println("Request Time: " + requestTime);
		
		//System.out.println("Before passing to the servlet, request URL: " + httpRequest.getRequestURL());
		chain.doFilter(request, response);
		//System.out.println("After passing through filter.");
			
		
		
		
		
		
		
		
	}

	
	
}
