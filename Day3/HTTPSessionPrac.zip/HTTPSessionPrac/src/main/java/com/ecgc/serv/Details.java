package com.ecgc.serv;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


@WebServlet("/details")
public class Details extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public Details() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String fn = request.getParameter("firstname");
		String email = request.getParameter("email");
		String ln = request.getParameter("lastname");
		
		// Here you can process the details as needed, e.g., save to a database or session
		// For demonstration, we'll just print them to the console
		System.out.println("Name: " + fn + " " + ln);
		System.out.println("Email: " + email);
		
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<html><body>");
		out.println("<h1>Details Submitted Successfully!</h1>");
		out.println("<p>Name: " + fn + " " + ln + "</p>");
		out.println("<p>Email: " + email + "</p>");
		out.println("</body></html>");
		
		//create a logout
		out.println("<a href='logout'>Logout</a>");
		out.close();
		
		
	
//		Cookie[] cookies = request.getCookies();
//		if (cookies != null) {
//			for (Cookie cookie : cookies) {
//				if ("admin".equals(cookie.getName())) {
//					String username = cookie.getValue();
//					out.println("<p>Username from Cookie: " + username + "</p>");
//				}
//			}
//		} else {
//			out.println("<p>No cookies found.</p>");
//		}
		
		out.close();
		
		// Optionally, you can redirect to another page or forward the request
		// response.sendRedirect("someOtherPage.jsp");
		// or
		// RequestDispatcher dispatcher = request.getRequestDispatcher("someOtherPage.jsp");
		// dispatcher.forward(request, response);
				
	}

}
