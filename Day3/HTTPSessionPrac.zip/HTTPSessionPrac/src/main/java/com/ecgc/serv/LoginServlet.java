package com.ecgc.serv;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;


@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public LoginServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
//		System.out.println("Username: " + username);
//		System.out.println("Password: " + password);
//		
		
		HttpSession session = request.getSession();
		session.setAttribute("username", username);
		
		//store the username in a cookie
		Cookie userCookie = new Cookie("username", username);
		userCookie.setMaxAge(60*60);// Set cookie to expire in 60 seconds
		response.addCookie(userCookie);
		
		// Validate the username and password
		if ("admin".equals(username) && "admin123".equals(password)) {
			//response.sendRedirect("home");
			RequestDispatcher dispatcher = request.getRequestDispatcher("home");
			dispatcher.forward(request, response);
		} else {
			response.sendRedirect("login.html");
		}
		
	}

}
