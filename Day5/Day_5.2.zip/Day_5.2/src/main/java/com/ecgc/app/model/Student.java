package com.ecgc.app.model;

public class Student {
	
	private int Id;
	private String Name;
	
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public Student(int id, String name) {
		super();
		Id = id;
		Name = name;
	}
	public Student() {
		super();
	}
	
	

}
