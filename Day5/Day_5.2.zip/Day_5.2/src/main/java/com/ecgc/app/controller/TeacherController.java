package com.ecgc.app.controller;

public class TeacherController {

}
