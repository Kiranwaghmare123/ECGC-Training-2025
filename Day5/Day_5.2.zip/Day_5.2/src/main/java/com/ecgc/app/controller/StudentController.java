package com.ecgc.app.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ecgc.app.model.Student;

@Controller
@RequestMapping("/student")
public class StudentController {
	
	ArrayList<Student> students=new ArrayList<Student>();
	
	public StudentController() {
		students.add(new Student(101,"Malkeet"));
		students.add(new Student(102,"Malkeet"));
		students.add(new Student(103,"Malkeet"));
	}
	
	@GetMapping("/GetAll")
	@ResponseBody
	List<Student> GetAllStudents()
	{
		return students;
	}

}
