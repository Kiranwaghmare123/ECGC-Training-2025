package com.cdac.comp;

public class MyBean {
	private String msg;
	
	//Constructor 
	public MyBean() {
		
	}
	public MyBean(String msg) {
		super();
		this.msg = msg;
	}
	//Setter Getter
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	@Override
	public String toString() {
		return "MyBean [msg=" + msg + "]";
	}
	
	
	

}
