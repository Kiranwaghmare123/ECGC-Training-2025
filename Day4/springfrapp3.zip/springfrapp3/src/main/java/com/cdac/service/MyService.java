package com.cdac.service;

import com.cdac.dao.MyDao;

public class MyService {
	private MyDao myDao;
	//setter-getter
	public MyDao getMyDao() {
		return myDao;
	}

	public void setMyDao(MyDao myDao) {
		this.myDao = myDao;
	}
	//additional method
	
	public void add() {
		System.out.println("add() is called");
		myDao.save();
	}
	


}
