package com.cdac.dao;

public class MyDao {
	
	public void save() {
		System.out.println("save() is called");
	}

}
