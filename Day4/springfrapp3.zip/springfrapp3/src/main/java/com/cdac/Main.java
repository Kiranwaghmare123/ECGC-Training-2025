package com.cdac;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cdac.service.MyService;

public class Main {

	public static void main(String[] args) {
		System.out.println("Hello World");
		ApplicationContext context = new ClassPathXmlApplicationContext("cfg.xml");
		MyService ms = (MyService) context.getBean("serv");
		ms.add();
	}

}
