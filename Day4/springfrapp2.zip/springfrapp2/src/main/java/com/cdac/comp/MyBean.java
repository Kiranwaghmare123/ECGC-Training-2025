package com.cdac.comp;

public class MyBean {
	
	private int msgid;
	private String msg;
	
	public MyBean() {
		
	}

	public MyBean(int msgid, String msg) {
		super();
		this.msgid = msgid;
		this.msg = msg;
	}

	public int getMsgid() {
		return msgid;
	}

	public void setMsgid(int msgid) {
		this.msgid = msgid;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	@Override
	public String toString() {
		return "MyBean [msgid=" + msgid + ", msg=" + msg + "]";
	}
	
	
	
	//Constructor
	
	//setter-getter
	//toString() method
	

}
