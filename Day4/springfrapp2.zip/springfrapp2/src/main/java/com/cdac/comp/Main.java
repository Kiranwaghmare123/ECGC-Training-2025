package com.cdac.comp;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		System.out.println("Hello World");
		ApplicationContext context = new ClassPathXmlApplicationContext("cfg.xml");
		MyBean mb = (MyBean) context.getBean("my");
		System.out.println(mb.getMsgid());
		System.out.println(mb.getMsg());

	}

}
